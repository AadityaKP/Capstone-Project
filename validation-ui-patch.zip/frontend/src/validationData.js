export const edgarCaseStudies = [
  {
    "ticker": "ZM",
    "quarter": "2018Q2",
    "priceAssumed": 50.0,
    "actualGrowth": 1.0307641085400365,
    "hold": 0.8823519961996426,
    "noAction": 0.0021735393721032947,
    "simpleRules": 0.31277322039752964,
    "advisoryBoard": 0.38764807586371297,
    "deathsBoard": 0,
    "agentIncrement": -0.5169671922965913,
    "companyName": "Zoom Communications",
    "description": "Video communications and collaboration software."
  },
  {
    "ticker": "ZETA",
    "quarter": "2020Q2",
    "priceAssumed": 50.0,
    "actualGrowth": 0.38591987553481144,
    "hold": 0.7907894753461465,
    "noAction": 0.0021735393721034058,
    "simpleRules": 0.3060927237742934,
    "advisoryBoard": 0.38371183172935164,
    "deathsBoard": 0,
    "agentIncrement": -0.43383959343029066,
    "companyName": "Zeta Global",
    "description": "Data-driven marketing technology and customer engagement software."
  },
  {
    "ticker": "PCTY",
    "quarter": "2013Q1",
    "priceAssumed": 50.0,
    "actualGrowth": 0.40656502541031414,
    "hold": 0.7921539452349228,
    "noAction": 0.0021735393721031837,
    "simpleRules": 0.3057326577611622,
    "advisoryBoard": 0.3837159705105945,
    "deathsBoard": 0,
    "agentIncrement": -0.4345263588012426,
    "companyName": "Paylocity",
    "description": "Cloud-based payroll and human capital management software."
  },
  {
    "ticker": "MDB",
    "quarter": "2017Q4",
    "priceAssumed": 50.0,
    "actualGrowth": 0.7301870420362515,
    "hold": 0.9807811257252602,
    "noAction": 0.0021735393721031837,
    "simpleRules": 0.32390990690504484,
    "advisoryBoard": 0.3876480758637133,
    "deathsBoard": 0,
    "agentIncrement": -0.6142903318606561,
    "companyName": "MongoDB",
    "description": "Developer data platform and database software."
  },
  {
    "ticker": "DOCN",
    "quarter": "2020Q1",
    "priceAssumed": 50.0,
    "actualGrowth": 0.2866935927024947,
    "hold": 0.8052653108371787,
    "noAction": 0.0021735393721032947,
    "simpleRules": 0.31380031555138244,
    "advisoryBoard": 0.3837118317293512,
    "deathsBoard": 0,
    "agentIncrement": -0.44023877002806533,
    "companyName": "DigitalOcean",
    "description": "Cloud infrastructure and developer platform services."
  }
];

// Aggregate results from validation/results/agent_scorecard.csv.
// These are simulation experiments, not real-world causal effects.
export const oracleEvidence = {
  oracleV3: {
    comparison: "Oracle v3 vs advisory board",
    metric: "Mean final MRR difference",
    value: 861622.3,
    ciLow: 659856.3,
    ciHigh: 1070013.2,
    positiveSeeds: 75,
    totalSeeds: 75,
    p: "5.3e-14",
    note: "Recorded full run; paired-seed analysis."
  },
  baseline: [
    { label: "Advisory board vs no action", meanDifference: 2208264, p: "1.6e-14", seeds: 50 },
    { label: "Advisory board vs simple rules", meanDifference: 211399, p: "1.6e-14", seeds: 50 },
    { label: "Advisory board vs random policy", meanDifference: 2146967, p: "4e-12", seeds: 50 }
  ]
};
