import React, { useMemo, useState } from "react";
import {
  Activity, AlertTriangle, BarChart3, CheckCircle2, Database,
  ExternalLink, FlaskConical, Info, TrendingUp
} from "lucide-react";
import { edgarCaseStudies, oracleEvidence } from "../validationData.js";

const pct = (value) => value == null || !Number.isFinite(value)
  ? "—"
  : `${value >= 0 ? "+" : ""}${(value * 100).toFixed(1)}%`;
const money = (value) => new Intl.NumberFormat("en-US", {
  style: "currency", currency: "USD", maximumFractionDigits: 0
}).format(value);
const policyRows = (c) => [
  { label: "Observed company growth", key: "actualGrowth", value: c.actualGrowth, kind: "actual" },
  { label: "No action", key: "noAction", value: c.noAction, kind: "no-action" },
  { label: "Simple rules", key: "simpleRules", value: c.simpleRules, kind: "rules" },
  { label: "Advisory board", key: "advisoryBoard", value: c.advisoryBoard, kind: "board" },
];

function GrowthBars({ company }) {
  const rows = policyRows(company);
  const max = Math.max(1, ...rows.map((r) => Math.abs(r.value || 0)));
  return (
    <div className="validation-bars" role="img" aria-label={`Observed and simulated four-quarter growth for ${company.ticker}`}>
      {rows.map((row) => (
        <div className="validation-bar-row" key={row.key}>
          <div className="validation-bar-label">{row.label}</div>
          <div className="validation-bar-track">
            <div
              className={`validation-bar ${row.kind}`}
              style={{ width: `${Math.max(1, Math.abs(row.value || 0) / max * 100)}%` }}
            />
          </div>
          <strong>{pct(row.value)}</strong>
        </div>
      ))}
      <div className="validation-axis"><span>0%</span><span>Relative growth over 4 quarters</span><span>{pct(max)}</span></div>
    </div>
  );
}

export default function Validation() {
  const [ticker, setTicker] = useState("PCTY");
  const company = useMemo(
    () => edgarCaseStudies.find((c) => c.ticker === ticker) || edgarCaseStudies[0],
    [ticker]
  );
  const oracle = oracleEvidence.oracleV3;

  return (
    <section className="content-stack validation-page">
      <div className="section-heading validation-intro">
        <div>
          <div className="validation-eyebrow"><FlaskConical size={15} /> RESEARCH & EVIDENCE</div>
          <h2>Validation &amp; Results</h2>
          <p>How the advisory policies compare with historical public-company data and controlled simulation experiments.</p>
        </div>
        <span className="status-pill neutral"><Database size={13} /> SEC EDGAR XBRL</span>
      </div>

      <div className="validation-callout">
        <Info size={19} />
        <div>
          <strong>What this page demonstrates</strong>
          <p>EDGAR provides the observed company trajectory. The alternative policy outcomes are simulator counterfactuals initialized from historical company states—not results the real company actually obtained by following AI advice.</p>
        </div>
      </div>

      <div className="validation-stat-grid">
        <article className="validation-stat">
          <span>EDGAR panel</span><strong>39 companies</strong>
          <small>Software / SaaS public companies</small>
        </article>
        <article className="validation-stat">
          <span>Complete core quarters</span><strong>1,288</strong>
          <small>2010 Q2 – 2026 Q2</small>
        </article>
        <article className="validation-stat">
          <span>Oracle v3 paired runs</span><strong>75 / 75</strong>
          <small>Seeds with positive final-MRR difference vs boardroom</small>
        </article>
      </div>

      <article className="panel validation-panel">
        <div className="panel-title">
          <Database size={17} />
          <div><h3>EDGAR company case study</h3><p>Select a company from the review panel to compare its observed four-quarter growth with simulator counterfactuals.</p></div>
        </div>
        <div className="validation-company-head">
          <label className="rv-field">
            <span>Company</span>
            <select value={ticker} onChange={(e) => setTicker(e.target.value)}>
              {edgarCaseStudies.map((c) => <option value={c.ticker} key={c.ticker}>{c.ticker} — {c.companyName}</option>)}
            </select>
          </label>
          <div className="validation-company-summary">
            <span className="validation-ticker">{company.ticker}</span>
            <div><strong>{company.companyName}</strong><p>{company.description}</p></div>
            <span className="status-pill neutral">Start: {company.quarter}</span>
          </div>
        </div>

        <div className="validation-chart-title">
          <div><h4>Observed vs simulated growth</h4><p>Next four quarters · growth rates from the saved real-company backtest</p></div>
          <span className="status-pill neutral">Historical + counterfactual</span>
        </div>
        <GrowthBars company={company} />

        <div className="validation-legend">
          <span><i className="legend-dot actual" />Observed EDGAR outcome</span>
          <span><i className="legend-dot no-action" />No action</span>
          <span><i className="legend-dot rules" />Simple rules</span>
          <span><i className="legend-dot board" />Advisory board</span>
        </div>
        <p className="validation-footnote">The simulation uses assumed parameters where EDGAR does not disclose them (including price and churn). These are model-based counterfactuals, not causal estimates. The saved real-company backtest does not contain a per-company Oracle-guided arm, so Oracle is reported separately below from the controlled agent experiments.</p>
      </article>

      <article className="panel validation-panel">
        <div className="panel-title">
          <BarChart3 size={17} />
          <div><h3>Controlled policy experiments</h3><p>Matched-seed simulator comparisons isolate policy effects under the same simulated conditions.</p></div>
        </div>
        <div className="validation-experiment-grid">
          {oracleEvidence.baseline.map((item) => (
            <div className="validation-experiment-card" key={item.label}>
              <span className="validation-card-icon"><TrendingUp size={17} /></span>
              <strong>{item.label}</strong>
              <div className="validation-experiment-value">+{money(item.meanDifference)}</div>
              <p>Mean final-MRR difference · {item.seeds} matched seeds</p>
              <span className="validation-p-value">Holm-adjusted p = {item.p}</span>
            </div>
          ))}
        </div>
        <div className="validation-oracle">
          <div className="validation-oracle-icon"><Activity size={20} /></div>
          <div className="validation-oracle-copy">
            <span className="validation-eyebrow">ORACLE VALUE · RECORDED FULL RUN</span>
            <h4>Oracle v3 vs advisory board</h4>
            <p>Mean final-MRR difference: <strong>+{money(oracle.value)}</strong> (95% CI reported in the validation scorecard: {money(oracle.ciLow)} to {money(oracle.ciHigh)}). Positive in {oracle.positiveSeeds} of {oracle.totalSeeds} paired seeds; p = {oracle.p}.</p>
          </div>
        </div>
        <p className="validation-footnote">These figures are simulation outcomes, not real-world revenue gains. They support comparisons within the simulator and do not prove that adopting the advice would cause a public company to grow faster.</p>
      </article>

      <article className="panel validation-panel">
        <div className="panel-title">
          <CheckCircle2 size={17} />
          <div><h3>What validation found</h3><p>Important results and limitations from the saved validation scorecards.</p></div>
        </div>
        <div className="validation-findings">
          <div className="validation-finding positive">
            <CheckCircle2 size={17} />
            <div><strong>Growth behaviour and spend ratios improved under the v2 calibration</strong><p>In the v2 recoverable-shock evaluation, growth deceleration with scale and discretionary-spend ratios passed the recorded checks.</p></div>
          </div>
          <div className="validation-finding caution">
            <AlertTriangle size={17} />
            <div><strong>Real-company counterfactual is not a success claim</strong><p>The saved scorecard flags the original real-company retrodiction and agent-vs-hold comparison as failures. The marketing response was too generous at real-company spend levels, so the model cannot support a claim that the agent improves real-world company outcomes.</p></div>
          </div>
          <div className="validation-finding caution">
            <AlertTriangle size={17} />
            <div><strong>EDGAR has important coverage limits</strong><p>Public filings do not provide quarterly churn, CAC, LTV, product quality, or customer counts. Some inputs must be assumed, and successful public SaaS companies are not representative of early-stage startups.</p></div>
          </div>
        </div>
      </article>

      <div className="validation-footer">
        <span>Source: repository validation scorecards, real-company backtest, and EDGAR data audit.</span>
        <button type="button" className="secondary-button small" onClick={() => { window.location.hash = "/dataset"; }}>
          <Database size={14} /> Explore EDGAR dataset <ExternalLink size={13} />
        </button>
      </div>
    </section>
  );
}
