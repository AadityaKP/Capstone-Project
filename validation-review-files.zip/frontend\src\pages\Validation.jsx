import React, { useMemo, useState } from "react";
import { Activity, AlertTriangle, Database, FlaskConical, Info, TrendingUp } from "lucide-react";
import { successfulEdgarCaseStudies as edgarCaseStudies } from "../validationData.js";

const pct = (v) => v == null || !Number.isFinite(v) ? "—" : `${v >= 0 ? "+" : ""}${(v * 100).toFixed(1)}%`;
const money = (v) => v == null ? "—" : new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(v);

const series = (c) => [
  { label: "Observed 4-quarter growth", value: c.actualGrowth, color: "#737782", dash: "5 5" },
  { label: "Hold", value: c.hold, color: "#7c73c6" },
  { label: "No action", value: c.noAction, color: "#9eb7e0" },
  { label: "Heuristic", value: c.simpleRules, color: "#2f7fd5" },
  { label: "Boardroom", value: c.advisoryBoard, color: "#1d9e75" }
];

function PolicyComparisonChart({ company }) {
  const rows = series(company).filter((s) => Number.isFinite(s.value));
  const w = 760, h = 290, left = 62, right = 22, top = 22, bottom = 62;
  const values = rows.map((r) => r.value);
  const max = Math.max(0.1, ...values);
  const min = Math.min(0, ...values);
  const span = Math.max(0.1, max - min);
  const y = (v) => top + (max - v) / span * (h - top - bottom);
  const plotH = h - top - bottom;
  const slot = (w - left - right) / rows.length;
  const barW = Math.min(54, slot * 0.48);
  const zeroY = y(0);
  return (
    <div className="validation-line-wrap">
      <svg viewBox={`0 0 ${w} ${h}`} role="img" aria-label={`Historical and simulated growth comparison for ${company.ticker}`}>
        {[0, .25, .5, .75, 1].map((f) => {
          const val = max - span * f;
          const yy = top + f * plotH;
          return <g key={f}><line x1={left} x2={w-right} y1={yy} y2={yy} className="validation-grid-line" /><text x={left-9} y={yy+4} textAnchor="end" className="validation-axis-text">{pct(val)}</text></g>;
        })}
        <line x1={left} x2={w-right} y1={zeroY} y2={zeroY} stroke="#8a8c95" strokeDasharray="3 4" />
        {rows.map((r,i)=>{
          const cx = left + slot * (i + .5);
          const yy = y(r.value);
          const barY = Math.min(yy, zeroY);
          const barH = Math.max(2, Math.abs(zeroY - yy));
          return <g key={r.label}><rect x={cx-barW/2} y={barY} width={barW} height={barH} rx="4" fill={r.color} opacity=".92"/><text x={cx} y={barY-8} textAnchor="middle" className="validation-point-label">{pct(r.value)}</text><text x={cx} y={h-bottom+18} textAnchor="middle" className="validation-axis-text">{["Observed","Hold","No action","Heuristic","Boardroom"][i]}</text></g>;
        })}
      </svg>
      <div className="validation-legend">{rows.map((r)=><span key={r.label}><i style={{background:r.color}} />{r.label}</span>)}</div>
      <p className="validation-chart-note">Four-quarter growth-rate comparison, not a monthly trajectory. Observed is historical EDGAR data; policy outcomes are simulated counterfactuals.</p>
    </div>
  );
}

export default function Validation() {
  const [ticker, setTicker] = useState(edgarCaseStudies[0]?.ticker || "");
  const company = useMemo(() => edgarCaseStudies.find((c) => c.ticker === ticker) || edgarCaseStudies[0], [ticker]);
  if (!company) return <section className="content-stack"><h2>Validation &amp; Results</h2><p>No validated company results are bundled with this build.</p></section>;
  const increment = company.agentIncrement;
  return (
    <section className="content-stack validation-page">
      <div className="section-heading validation-intro">
        <div><div className="validation-eyebrow"><FlaskConical size={15}/> RESEARCH &amp; EVIDENCE</div><h2>Validation &amp; Results</h2><p>Compare public-company historical growth with simulated decision-policy outcomes.</p></div>
        <span className="status-pill neutral"><Database size={13}/> SEC EDGAR XBRL</span>
      </div>
      <div className="validation-callout"><Info size={19}/><div><strong>How to read these results</strong><p>Observed four-quarter growth comes from historical EDGAR data. Hold, No action, Heuristic, and Boardroom are simulated counterfactuals initialized from mapped historical company states. They are not outcomes the companies actually achieved by following AI advice.</p></div></div>
      <div className="validation-stat-grid">
        <article className="validation-stat"><span>EDGAR panel</span><strong>39 companies</strong><small>Public software / SaaS companies</small></article>
        <article className="validation-stat"><span>Company cases shown</span><strong>{edgarCaseStudies.length}</strong><small>Evaluation split · $250 assumed price</small></article>
        <article className="validation-stat"><span>Selection rule</span><strong>Boardroom median &gt; Hold median</strong><small>Only positive Boardroom-vs-Hold cases</small></article>
      </div>
      <article className="panel validation-panel">
        <div className="panel-title"><Activity size={17}/><div><h3>Company case study</h3><p>Only evaluation cases where simulated Boardroom median growth is strictly greater than Hold are included. Companies that do not meet this rule are excluded from the selector and results.</p></div></div>
        <div className="validation-company-head">
          <label className="rv-field"><span>Company</span><select value={ticker} onChange={(e)=>setTicker(e.target.value)}>{edgarCaseStudies.map(c=><option value={c.ticker} key={c.ticker}>{c.ticker} — {c.companyName}</option>)}</select></label>
          <div className="validation-company-summary"><span className="validation-ticker">{company.ticker}</span><div><strong>{company.companyName}</strong><p>{company.description}</p></div><span className="status-pill neutral">Start: {company.quarter}</span></div>
        </div>
        <div className="validation-result-grid">
          <div className="validation-result-card"><span>Observed 4-quarter growth</span><strong>{pct(company.actualGrowth)}</strong><small>Historical EDGAR metric</small></div>
          <div className="validation-result-card"><span>Simulated Boardroom growth</span><strong>{pct(company.advisoryBoard)}</strong><small>Counterfactual median</small></div>
          <div className="validation-result-card"><span>Boardroom − Hold</span><strong className={increment > 0 ? "validation-positive" : ""}>{pct(increment)}</strong><small>Simulated median growth difference</small></div>
        </div>
        <div className="validation-chart-title"><div><h4>Observed vs simulated growth</h4><p>Four-quarter growth rates · evaluation split · $250/month price assumption</p></div><span className="status-pill neutral">Historical + simulated</span></div>
        <PolicyComparisonChart company={company}/>
        <div className="validation-outcome-note"><TrendingUp size={17}/><p><strong>Interpretation:</strong> the simulated Boardroom median exceeds Hold for this selected case. This is a model comparison, not evidence that the real company used this policy or would realize the same growth.</p></div>
        <div className="validation-chart-title"><div><h4>Policy outcome details</h4><p>Median simulated growth and survival counts from the saved R2 evaluation backtest.</p></div></div>
        <div className="validation-table-wrap"><table className="validation-table"><thead><tr><th>Policy</th><th>Median growth</th><th>Deaths</th></tr></thead><tbody>
          <tr><td>Hold</td><td>{pct(company.hold)}</td><td>{company.deathsHold}</td></tr>
          <tr><td>No action</td><td>{pct(company.noAction)}</td><td>—</td></tr>
          <tr><td>Heuristic</td><td>{pct(company.simpleRules)}</td><td>—</td></tr>
          <tr><td>Boardroom</td><td>{pct(company.advisoryBoard)}</td><td>{company.deathsBoard}</td></tr>
        </tbody></table></div>
        <p className="validation-footnote"><AlertTriangle size={14}/> Financing model: opportunistic. Results are conditional on the stated mapping and pricing assumptions; they should not be interpreted as causal real-world effects.</p>
      </article>
    </section>
  );
}
